function plot_deployment(x, P, ttl)
%PLOT_DEPLOYMENT  Top view of users, UAV positions and coverage discs.
if nargin < 3, ttl = ''; end
[~, o] = UAV_Fitness(x, P);
hold on; box on; axis equal;
th = linspace(0, 2*pi, 100);
cols = lines(P.N);
for j = 1:P.N
    fill(o.pos(j,1) + o.radius(j)*cos(th), o.pos(j,2) + o.radius(j)*sin(th), ...
         cols(j,:), 'FaceAlpha', 0.15, 'EdgeColor', cols(j,:), 'LineWidth', 1.2);
    plot(o.pos(j,1), o.pos(j,2), '^', 'MarkerSize', 10, 'MarkerFaceColor', cols(j,:), ...
         'MarkerEdgeColor', 'k');
    text(o.pos(j,1) + 1.5, o.pos(j,2) + 1.5, sprintf('D%d (h=%.1f m)', j, o.altitude(j)), ...
         'FontSize', 8);
end
cov = o.assoc > 0;
plot(P.users(cov,1),  P.users(cov,2),  'ko', 'MarkerFaceColor', [0.2 0.7 0.2]);
plot(P.users(~cov,1), P.users(~cov,2), 'kx', 'MarkerSize', 8, 'LineWidth', 1.5);
xlim([0 P.W]); ylim([0 P.L]);
xlabel('x (m)'); ylabel('y (m)');
title(sprintf('%s  coverage = %.1f%%, mean R = %.2f m', ttl, o.coverage_pct, o.mean_radius));
hold off;
end
