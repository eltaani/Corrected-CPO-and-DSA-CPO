function P = UAV_Problem_Setup(N_uav, M_users, userSeed, varargin)
%UAV_PROBLEM_SETUP  3-D UAV base-station placement problem.
%
%   P = UAV_Problem_Setup(N_uav, M_users, userSeed)
%   P = UAV_Problem_Setup(..., 'Name', value)   overrides any field below
%
%   Area W x L, M_users ground users at fixed positions, N_uav UAVs at
%   (X_j, Y_j, h_j). Footprint radius R_j = h_j tan(theta) (theta = 45 deg).
%   Decision vector (dimension 3 N_uav):  x = [X_1..X_N, Y_1..Y_N, h_1..h_N]
%
%   User layouts ('dist'):
%     'uniform'   (default) users uniform in the area. The layout is drawn
%                 from a master list of Mmax users generated with userSeed,
%                 so smaller scenarios are nested subsets of larger ones.
%     'clustered' a fraction clusterFrac of the users is drawn around
%                 nClusters hotspots (Gaussian, std clusterSigma, centres in
%                 the central 60 % of the area); the rest is uniform.
%   The users are drawn from a private RandStream: the global rng is untouched.

% ------------------------------- defaults ---------------------------------
P.W      = 100;            % area width  [m]
P.L      = 100;            % area length [m]
P.H      = 100;            % airspace height [m] (plotting only)
P.hmin   = 5;              % minimum altitude [m]
P.hmax   = 25;             % maximum altitude [m]
P.theta  = deg2rad(45);    % half-angle of the footprint (R = h at 45 deg)
P.m      = 1.5;            % UAV mass [kg]      (potential energy m g h)
P.g      = 9.81;           % gravity [m/s^2]
P.Mmax   = 40;             % size of the master user list
P.w      = [1.0, 0.25, 0.25];   % weights of F = wC(1-C) + wQ(1-Q) + wE*Ebar
P.dist   = 'uniform';      % 'uniform' | 'clustered'
P.nClusters   = 3;         % clustered layout: number of hotspots
P.clusterFrac = 0.7;       % clustered layout: fraction of users in hotspots
P.clusterSigma = 8;        % clustered layout: hotspot standard deviation [m]

% ------------------------------ overrides ---------------------------------
for k = 1:2:numel(varargin)
    P.(varargin{k}) = varargin{k+1};
end

P.N    = N_uav;
P.M    = M_users;
P.Rmax = P.hmax * tan(P.theta);
P.Mmax = max(P.Mmax, M_users);

% ------------------------------ users -------------------------------------
s = RandStream('mt19937ar', 'Seed', userSeed);
switch lower(P.dist)
    case 'uniform'
        U = [P.W * rand(s, P.Mmax, 1), P.L * rand(s, P.Mmax, 1)];
    case 'clustered'
        K  = P.nClusters;
        C  = [P.W * (0.2 + 0.6 * rand(s, K, 1)), P.L * (0.2 + 0.6 * rand(s, K, 1))];
        nC = round(P.clusterFrac * P.Mmax);
        k  = randi(s, K, nC, 1);
        Uc = C(k, :) + P.clusterSigma * randn(s, nC, 2);
        Uc = [min(max(Uc(:, 1), 0), P.W), min(max(Uc(:, 2), 0), P.L)];
        Uu = [P.W * rand(s, P.Mmax - nC, 1), P.L * rand(s, P.Mmax - nC, 1)];
        U  = [Uc; Uu];
        U  = U(randperm(s, P.Mmax), :);
    otherwise
        error('UAV_Problem_Setup: unknown dist ''%s''.', P.dist);
end
P.users = U(1:M_users, :);

% ------------------------------ bounds ------------------------------------
P.dim = 3 * N_uav;
P.lb  = [zeros(1, N_uav),      zeros(1, N_uav),      P.hmin * ones(1, N_uav)];
P.ub  = [P.W * ones(1, N_uav), P.L * ones(1, N_uav), P.hmax * ones(1, N_uav)];
end
