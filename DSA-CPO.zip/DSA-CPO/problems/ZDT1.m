function f = ZDT1(x)
%ZDT1  Bi-objective ZDT1 benchmark (minimisation of both objectives).
%
%   f = ZDT1(x)   x: 1 x n row vector in [0,1]^n (n = 30 in the standard
%                 definition), f = [f1, f2]
%
%   f1 = x1
%   g  = 1 + 9 * sum(x2..xn) / (n - 1)
%   f2 = g * (1 - sqrt(f1 / g))
%
%   Pareto-optimal solutions: x2 = ... = xn = 0 (g = 1).
%   Pareto front (convex): f2 = 1 - sqrt(f1), f1 in [0, 1].
%
%   E. Zitzler, K. Deb and L. Thiele, "Comparison of multiobjective
%   evolutionary algorithms: Empirical results," Evolutionary Computation,
%   vol. 8, no. 2, pp. 173-195, 2000.

x  = x(:).';
f1 = x(1);
g  = 1 + 9 * sum(x(2:end)) / (numel(x) - 1);
f  = [f1, g * (1 - sqrt(f1 / g))];
end
