function [F, out] = UAV_Fitness(x, P)
%UAV_FITNESS  Fitness (to minimise) of a UAV-BS placement x = [X, Y, h].
%
%   C    = fraction of users within the footprint of at least one UAV
%   Q    = sum_i max_j max(0, R_j - d_ij) / (M Rmax)      coverage margin
%   Ebar = sum_j h_j / (N hmax)                            altitude penalty
%   F    = wC (1 - C) + wQ (1 - Q) + wE Ebar   >= 0
%
%   d_ij is the horizontal distance between user i and the ground projection
%   of UAV j. F is non-negative because CPO's odor and physical-attack
%   defences use exp(f_i / sum_k f_k).

N  = P.N;
x  = x(:).';
ux = x(1:N);
uy = x(N+1:2*N);
h  = min(max(x(2*N+1:3*N), P.hmin), P.hmax);

R  = h * tan(P.theta);                       % 1 x N footprint radii
dx = P.users(:, 1) - ux;                     % M x N (implicit expansion)
dy = P.users(:, 2) - uy;
d  = sqrt(dx.^2 + dy.^2);

gam     = max(0, R - d);                     % coverage margin per pair
q_user  = max(gam, [], 2);                   % best UAV for each user
covered = any(d <= R, 2);

C     = mean(covered);
Q     = sum(q_user) / (P.M * P.Rmax);
Enorm = sum(h) / (N * P.hmax);

F = P.w(1) * (1 - C) + P.w(2) * (1 - Q) + P.w(3) * Enorm;

if nargout > 1
    [~, assoc] = max(gam, [], 2);            % serving UAV of each user
    assoc(~covered) = 0;
    out.coverage_pct   = 100 * C;
    out.quality        = sum(q_user);        % total coverage margin [m]
    out.quality_norm   = Q;
    out.mean_radius    = mean(R);            % mean footprint radius [m]
    out.radius         = R;
    out.altitude       = h;
    out.energy_J       = P.m * P.g * h;      % potential energy per UAV [J]
    out.total_energy_J = sum(out.energy_J);
    out.n_covered      = sum(covered);
    out.assoc          = assoc;              % 0 = not covered
    out.pos            = [ux(:), uy(:), h(:)];
    out.fitness        = F;
end
end
