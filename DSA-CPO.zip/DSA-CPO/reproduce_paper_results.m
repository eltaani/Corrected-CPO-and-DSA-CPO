%% REPRODUCE_PAPER_RESULTS  DSA-CPO and CPO on the 15 scenarios of the paper
%  Nd = 1..8 UAVs with 30 users, and Nu = 5..40 users with 5 UAVs
%  (Nd = 5, Nu = 30 appears once). 30 runs, population 30, 30,000 evaluations.
%  Run r uses rng(1000 + r, 'twister') for both algorithms, so both start
%  from the same initial population. Users: uniform, user seed 1.
clear; clc;
root = fileparts(mfilename('fullpath'));            % folder of this script
addpath(fullfile(root, 'algorithms'), fullfile(root, 'problems'));
runs = 30; pop = 30; MaxFEs = 30000;
sc = [(1:8)', 30 * ones(8, 1); 5 * ones(7, 1), [5 10 15 20 25 35 40]'];
nS = size(sc, 1);
F  = zeros(nS, 2, runs);  covPct = F;  t = F;

for s = 1:nS
    P = UAV_Problem_Setup(sc(s, 1), sc(s, 2), 1);
    fobj = @(x) UAV_Fitness(x, P);
    for r = 1:runs
        rng(1000 + r, 'twister'); tic;
        [~, bX] = DSA_CPO(pop, MaxFEs, P.lb, P.ub, P.dim, fobj);
        t(s, 1, r) = toc;  [F(s, 1, r), o] = UAV_Fitness(bX, P);  covPct(s, 1, r) = o.coverage_pct;

        rng(1000 + r, 'twister'); tic;
        [~, bX] = CPO(pop, MaxFEs, P.lb, P.ub, P.dim, fobj);
        t(s, 2, r) = toc;  [F(s, 2, r), o] = UAV_Fitness(bX, P);  covPct(s, 2, r) = o.coverage_pct;
    end
    fprintf('Nd = %d, Nu = %2d | DSA-CPO %.4f +- %.4f | CPO %.4f +- %.4f\n', sc(s, 1), sc(s, 2), ...
        mean(F(s, 1, :)), std(F(s, 1, :)), mean(F(s, 2, :)), std(F(s, 2, :)));
end
fprintf('Mean run time: DSA-CPO %.3f s, CPO %.3f s\n', mean(t(:, 1, :), 'all'), mean(t(:, 2, :), 'all'));
save('main_results.mat', 'F', 'covPct', 't', 'sc');
