%% MAIN_ZDT1  DSA-CPO on the ZDT1 benchmark
%
%  ZDT1 has two objectives, whereas DSA-CPO is a single-objective optimizer.
%  The Pareto front is approximated by decomposition: for each weight vector
%  w = (lambda, 1 - lambda), DSA-CPO minimises the weighted Tchebycheff function
%
%        g(x | w) = max( w1 |f1(x) - z1| , w2 |f2(x) - z2| ),
%
%  where z = (0, 0) is the ideal point of ZDT1. Each run gives one point of
%  the front. Quality: IGD, GD (distance to the true front, lower is better)
%  and hypervolume HV with reference point (1.1, 1.1) (higher is better).

clear; clc; close all;
root = fileparts(mfilename('fullpath'));            % folder of this script
addpath(fullfile(root, 'algorithms'), fullfile(root, 'problems'));

% ------------------------------- settings ---------------------------------
dim       = 30;            % number of variables (standard ZDT1)
lb        = zeros(1, dim);
ub        = ones(1, dim);
nW        = 50;            % number of weight vectors = points on the front
pop       = 30;            % population size
MaxFEs    = 5000;          % evaluations per weight vector
z         = [0, 0];        % ideal point of ZDT1
optimizer = @DSA_CPO;      % use @CPO to run the original CPO

algName = strrep(func2str(optimizer), '_', '-');
lambda  = linspace(0, 1, nW)';
W = max([lambda, 1 - lambda], 1e-6);       % no exactly-zero weight

% ----------------------------- optimisation -------------------------------
X  = zeros(nW, dim);
PF = zeros(nW, 2);
tic;
for k = 1:nW
    g = @(x) max(W(k, :) .* abs(ZDT1(x) - z));    % Tchebycheff subproblem k
    rng(k, 'twister');                             % reproducible runs
    [~, X(k, :)] = optimizer(pop, MaxFEs, lb, ub, dim, g);
    PF(k, :) = ZDT1(X(k, :));
end
fprintf('%s: %d subproblems x %d evaluations in %.1f s\n', algName, nW, MaxFEs, toc);

% --------------------------- quality indicators ---------------------------
f1 = linspace(0, 1, 1000)';
trueFront = [f1, 1 - sqrt(f1)];
D   = sqrt((trueFront(:, 1) - PF(:, 1)').^2 + (trueFront(:, 2) - PF(:, 2)').^2);
IGD = mean(min(D, [], 2));                 % true front -> obtained points
GD  = mean(min(D, [], 1));                 % obtained points -> true front
HV  = hypervolume2D(PF, [1.1, 1.1]);
fprintf('IGD = %.4e | GD = %.4e | HV = %.4f (true front: %.4f)\n', ...
        IGD, GD, HV, 1.21 - 1/3);

% --------------------------------- plot -----------------------------------
figure('Color', 'w');
plot(trueFront(:, 1), trueFront(:, 2), 'k-', 'LineWidth', 1.2); hold on;
plot(PF(:, 1), PF(:, 2), 'o', 'MarkerSize', 6, 'MarkerFaceColor', [0.85 0.33 0.10], ...
     'MarkerEdgeColor', 'k');
xlabel('f_1'); ylabel('f_2'); grid on; axis([0 1.05 0 1.05]);
legend('True Pareto front', algName, 'Location', 'northeast');
title(sprintf('ZDT1 (n = %d): IGD = %.2e, HV = %.4f', dim, IGD, HV));

% -------------------------------------------------------------------------
function hv = hypervolume2D(F, ref)
% hypervolume of a set of 2-objective points (minimisation)
F = F(all(F < ref, 2), :);
keep = true(size(F, 1), 1);                  % non-dominated filtering
for i = 1:size(F, 1)
    keep(i) = ~any(all(F <= F(i, :), 2) & any(F < F(i, :), 2));
end
F = sortrows(unique(F(keep, :), 'rows'), 1);
hv = 0; prev = ref(2);
for i = 1:size(F, 1)
    hv = hv + (ref(1) - F(i, 1)) * (prev - F(i, 2));
    prev = F(i, 2);
end
end
