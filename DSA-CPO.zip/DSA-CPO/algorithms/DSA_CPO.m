function [bestF, bestX, curve, info] = DSA_CPO(N0, MaxFEs, lb, ub, dim, fobj, opts)
%DSA_CPO  Diversity- and Stagnation-Aware Crested Porcupine Optimizer (minimisation).
%
%   [bestF, bestX, curve, info] = DSA_CPO(N0, MaxFEs, lb, ub, dim, fobj)
%   [bestF, bestX, curve, info] = DSA_CPO(N0, MaxFEs, lb, ub, dim, fobj, opts)
%
%   N0      initial population size N'
%   MaxFEs  budget of objective-function evaluations T_max
%   lb, ub  lower / upper bounds (scalars or 1 x dim vectors)
%   dim     number of decision variables D
%   fobj    function handle f = fobj(x), x a 1 x dim row vector, f >= 0
%           (CPO's odor and physical-attack moves use f_i / sum_k f_k)
%   opts    optional struct (defaults in brackets)
%       --- CPO parameters ---
%       .Nmin      [max(5, round(2N'/3))]  minimum population size
%       .T         [2]     number of population-reduction cycles
%       .alpha     [0.2]   convergence-speed factor
%       .Tf        [0.8]   odor vs. physical-attack trade-off
%       --- DSA controller ---
%       .Pstart, .Pend  [0.6, 0.3]  linear baseline P_0(t)
%       .Dref0     [0.5]   reference diversity D_ref(t) = Dref0 (1 - t/T_max)
%       .kD, .kS   [0.5, 0.3]  diversity gain and stagnation gain
%       .Pmin, .Pmax  [0.1, 0.9]  clipping of P_E
%       .Ws        [10]    stagnation window (iterations)
%       .deltaS    [1e-3]  relative improvement regarded as normal progress
%
%   Outputs
%       bestF, bestX  best fitness and solution
%       curve         best-so-far fitness after each evaluation (1 x MaxFEs)
%       info          per-iteration controller trace: .fe .PE .div .stag .Nt
%
%   Exploration probability (once per iteration):
%       P_E = clip( P_0(t) + (kD + kS*S) * (D_ref(t) - Div/Div(0)), Pmin, Pmax )
%   with Div the normalised diversity of the active population and S in [0,1]
%   the stagnation of the best fitness over the last Ws iterations.
%   Everything else is identical to CPO.m (same defences, population cycle,
%   greedy selection, clipping and random-number sequence): DSA-CPO and CPO
%   differ only in how P_E is computed.
%
%   Reproducibility: rng(1000 + r, 'twister') before the call (r = 1..30)
%   reproduces the DSA-CPO results reported in the paper.
%
%   R. El Taani, K. Baiche, Y. Tabet and Y. Meraihi, "An Adaptive Crested
%   Porcupine Optimizer for 3D UAV Base Station Placement," ICCEIS 2026.
%   Base algorithm: M. Abdel-Basset, R. Mohamed and M. Abouhawwash, "Crested
%   Porcupine Optimizer," Knowledge-Based Systems, vol. 284, 111257, 2024.

% ------------------------------- options ----------------------------------
if nargin < 7 || isempty(opts), opts = struct(); end
def = struct('Nmin', max(5, round(2/3 * N0)), 'T', 2, ...
             'alpha', 0.2, 'Tf', 0.8, 'Pstart', 0.6, 'Pend', 0.3, 'Dref0', 0.5, ...
             'kD', 0.5, 'kS', 0.3, 'Pmin', 0.1, 'Pmax', 0.9, 'Ws', 10, 'deltaS', 1e-3);
fn = fieldnames(def);
for k = 1:numel(fn)
    if ~isfield(opts, fn{k}), opts.(fn{k}) = def.(fn{k}); end
end
if isscalar(lb), lb = lb * ones(1, dim); end
if isscalar(ub), ub = ub * ones(1, dim); end
lb = lb(:).'; ub = ub(:).';
Nmin     = min(opts.Nmin, N0);
cycleLen = MaxFEs / opts.T;

% ---------------------------- initialisation ------------------------------
X     = rand(N0, dim) .* (ub - lb) + lb;
fit   = zeros(1, N0);
curve = zeros(1, MaxFEs);
fe = 0; bestF = inf; bestX = X(1, :);
for i = 1:N0
    fit(i) = fobj(X(i, :));
    fe = fe + 1;
    if fit(i) < bestF, bestF = fit(i); bestX = X(i, :); end
    curve(fe) = bestF;
end
Nt       = N0;                           % active population size N_t
D0       = popDiversity(X, lb, ub);      % Div(0)
bestHist = bestF;                        % best fitness at the end of each iteration

maxIt = ceil(MaxFEs / max(1, Nmin)) + 5;
info.fe = nan(1, maxIt); info.PE = nan(1, maxIt); info.div = nan(1, maxIt);
info.stag = nan(1, maxIt); info.Nt = nan(1, maxIt);
it = 0;

% ------------------------------ main loop ---------------------------------
while fe < MaxFEs
    it = it + 1;
    tn = fe / MaxFEs;                                    % t / T_max

    % ----- DSA controller: exploration probability P_E -----
    Drel = popDiversity(X(1:Nt, :), lb, ub) / (D0 + eps);
    S    = stagnation(bestHist, opts.Ws, opts.deltaS);
    P0   = opts.Pstart + (opts.Pend - opts.Pstart) * tn;  % baseline P_0(t)
    Dref = opts.Dref0 * (1 - tn);                         % reference diversity
    PE   = P0 + (opts.kD + opts.kS * S) * (Dref - Drel);
    PE   = min(max(PE, opts.Pmin), opts.Pmax);

    r2 = rand;                               % tau_4 of the physical attack
    for i = 1:Nt
        U1 = rand(1, dim) > rand;            % random binary vector
        if rand < PE                         % exploration
            if rand < 0.5, k = 1; else, k = 2; end
        else                                 % exploitation
            if rand < opts.Tf, k = 3; else, k = 4; end
        end
        xi = X(i, :);
        switch k
            case 1   % sight
                y  = (xi + X(randi(Nt), :)) / 2;
                xn = xi + randn .* abs(2 * rand * bestX - y);
            case 2   % sound
                y  = (xi + X(randi(Nt), :)) / 2;
                xn = U1 .* xi + (1 - U1) .* (y + rand * (X(randi(Nt), :) - X(randi(Nt), :)));
            case 3   % odor
                gam   = 2 * rand * (1 - tn)^tn;                 % defence factor gamma_t
                delta = 2 * (rand(1, dim) < 0.5) - 1;           % sign vector in {-1,+1}
                St    = exp(fit(i) / (sum(fit(1:Nt)) + eps));   % odor diffusion factor
                Sv    = rand * delta .* gam .* St;
                xn    = (1 - U1) .* xi + U1 .* (X(randi(Nt), :) + ...
                        St * (X(randi(Nt), :) - X(randi(Nt), :)) - Sv);
            case 4   % physical attack
                gam   = 2 * rand * (1 - tn)^tn;
                delta = 2 * (rand(1, dim) < 0.5) - 1;
                m     = exp(fit(i) / (sum(fit(1:Nt)) + eps));   % predator mass
                F     = rand(1, dim) .* (m * (X(randi(Nt), :) - xi));
                Sv    = rand * delta .* gam .* F;
                xn    = bestX + (opts.alpha * (1 - r2) + r2) * (delta .* bestX - xi) - Sv;
        end
        xn = min(max(xn, lb), ub);                     % clipping at the bounds

        fNew = fobj(xn);                               % evaluation
        fe   = fe + 1;
        if fNew <= fit(i)                              % greedy selection
            X(i, :) = xn;
            fit(i)  = fNew;
            if fNew <= bestF, bestF = fNew; bestX = xn; end
        end
        curve(fe) = bestF;
        if fe >= MaxFEs, break; end
    end

    if it <= maxIt
        info.fe(it) = fe; info.PE(it) = PE; info.div(it) = Drel;
        info.stag(it) = S; info.Nt(it) = Nt;
    end
    bestHist(end + 1) = bestF; %#ok<AGROW>

    % ----- cyclic population reduction (truncated, clamped to [Nmin, N0]) -----
    % inactive individuals keep their positions and fitness (no re-evaluation)
    Nt = fix(Nmin + (N0 - Nmin) * (1 - rem(fe, cycleLen) / cycleLen));
    Nt = min(max(Nt, Nmin), N0);
end

keep = 1:min(it, maxIt);
info.fe = info.fe(keep); info.PE = info.PE(keep); info.div = info.div(keep);
info.stag = info.stag(keep); info.Nt = info.Nt(keep);
end

% -------------------------------------------------------------------------
function D = popDiversity(X, lb, ub)
% normalised diversity of the rows of X (active population)
[n, d] = size(X);
Z = (X - mean(X, 1)) ./ (ub - lb);
D = sqrt(sum(Z(:).^2) / (n * d));
end

function S = stagnation(bestHist, Ws, deltaS)
% S = 0: normal progress over the last Ws iterations; S = 1: no improvement.
% For the first Ws iterations the reference is the best initial fitness.
n = numel(bestHist);
if n < 2, S = 0; return; end
fOld = bestHist(max(1, n - Ws));
fNow = bestHist(n);
S = 1 - min(1, abs(fOld - fNow) / (abs(fOld) + eps) / deltaS);
end
