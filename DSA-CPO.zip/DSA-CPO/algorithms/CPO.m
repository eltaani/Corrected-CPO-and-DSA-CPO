function [bestF, bestX, curve] = CPO(N0, MaxFEs, lb, ub, dim, fobj, opts)
%CPO  Crested Porcupine Optimizer (minimisation).
%
%   [bestF, bestX, curve] = CPO(N0, MaxFEs, lb, ub, dim, fobj)
%   [bestF, bestX, curve] = CPO(N0, MaxFEs, lb, ub, dim, fobj, opts)
%
%   M. Abdel-Basset, R. Mohamed and M. Abouhawwash, "Crested Porcupine
%   Optimizer: A new nature-inspired metaheuristic," Knowledge-Based Systems,
%   vol. 284, 111257, 2024.
%
%   N0      initial population size N'
%   MaxFEs  budget of objective-function evaluations T_max
%   lb, ub  lower / upper bounds (scalars or 1 x dim vectors)
%   dim     number of decision variables D
%   fobj    function handle f = fobj(x), x a 1 x dim row vector, f >= 0
%           (the odor and physical-attack defences use f_i / sum_k f_k)
%   opts    optional struct (defaults in brackets)
%       .Nmin   [max(5, round(2N'/3))]  minimum population size
%       .T      [2]     number of population-reduction cycles
%       .alpha  [0.2]   convergence-speed factor
%       .Tf     [0.8]   odor vs. physical-attack trade-off
%
%   Outputs: best fitness, best solution, and the best-so-far fitness after
%   each evaluation (1 x MaxFEs).
%
%   Each individual explores (sight or sound defence) with the fixed
%   probability P_E = 1/2, otherwise exploits (odor defence with probability
%   Tf, physical attack otherwise). This file follows the published
%   equations and differs from the official MATLAB code in three points
%   (see README.md): the sign vector takes values in {-1,+1} (the official
%   code gives 0), the population-reduction formula uses rem(t,Tmax/T)/(Tmax/T)
%   (operator-precedence error in the official code), and out-of-bound
%   coordinates are clipped (the official code re-initialises them).
%   It is the CPO baseline of the paper: rng(1000 + r, 'twister') before the
%   call (r = 1..30) reproduces the CPO results reported there.

% ------------------------------- options ----------------------------------
if nargin < 7 || isempty(opts), opts = struct(); end
def = struct('Nmin', max(5, round(2/3 * N0)), 'T', 2, 'alpha', 0.2, 'Tf', 0.8);
fn = fieldnames(def);
for k = 1:numel(fn)
    if ~isfield(opts, fn{k}), opts.(fn{k}) = def.(fn{k}); end
end
if isscalar(lb), lb = lb * ones(1, dim); end
if isscalar(ub), ub = ub * ones(1, dim); end
lb = lb(:).'; ub = ub(:).';
Nmin     = min(opts.Nmin, N0);
cycleLen = MaxFEs / opts.T;

% ---------------------------- initialisation ------------------------------
X     = rand(N0, dim) .* (ub - lb) + lb;
fit   = zeros(1, N0);
curve = zeros(1, MaxFEs);
fe = 0; bestF = inf; bestX = X(1, :);
for i = 1:N0
    fit(i) = fobj(X(i, :));
    fe = fe + 1;
    if fit(i) < bestF, bestF = fit(i); bestX = X(i, :); end
    curve(fe) = bestF;
end
Nt = N0;                                 % active population size N_t
PE = 0.5;                                % fixed exploration probability

% ------------------------------ main loop ---------------------------------
while fe < MaxFEs
    tn = fe / MaxFEs;                                    % t / T_max

    r2 = rand;                               % tau_4 of the physical attack
    for i = 1:Nt
        U1 = rand(1, dim) > rand;            % random binary vector
        if rand < PE                         % exploration
            if rand < 0.5, k = 1; else, k = 2; end
        else                                 % exploitation
            if rand < opts.Tf, k = 3; else, k = 4; end
        end
        xi = X(i, :);
        switch k
            case 1   % sight
                y  = (xi + X(randi(Nt), :)) / 2;
                xn = xi + randn .* abs(2 * rand * bestX - y);
            case 2   % sound
                y  = (xi + X(randi(Nt), :)) / 2;
                xn = U1 .* xi + (1 - U1) .* (y + rand * (X(randi(Nt), :) - X(randi(Nt), :)));
            case 3   % odor
                gam   = 2 * rand * (1 - tn)^tn;                 % defence factor gamma_t
                delta = 2 * (rand(1, dim) < 0.5) - 1;           % sign vector in {-1,+1}
                St    = exp(fit(i) / (sum(fit(1:Nt)) + eps));   % odor diffusion factor
                Sv    = rand * delta .* gam .* St;
                xn    = (1 - U1) .* xi + U1 .* (X(randi(Nt), :) + ...
                        St * (X(randi(Nt), :) - X(randi(Nt), :)) - Sv);
            case 4   % physical attack
                gam   = 2 * rand * (1 - tn)^tn;
                delta = 2 * (rand(1, dim) < 0.5) - 1;
                m     = exp(fit(i) / (sum(fit(1:Nt)) + eps));   % predator mass
                F     = rand(1, dim) .* (m * (X(randi(Nt), :) - xi));
                Sv    = rand * delta .* gam .* F;
                xn    = bestX + (opts.alpha * (1 - r2) + r2) * (delta .* bestX - xi) - Sv;
        end
        xn = min(max(xn, lb), ub);                     % clipping at the bounds

        fNew = fobj(xn);                               % evaluation
        fe   = fe + 1;
        if fNew <= fit(i)                              % greedy selection
            X(i, :) = xn;
            fit(i)  = fNew;
            if fNew <= bestF, bestF = fNew; bestX = xn; end
        end
        curve(fe) = bestF;
        if fe >= MaxFEs, break; end
    end

    % ----- cyclic population reduction (truncated, clamped to [Nmin, N0]) -----
    % inactive individuals keep their positions and fitness (no re-evaluation)
    Nt = fix(Nmin + (N0 - Nmin) * (1 - rem(fe, cycleLen) / cycleLen));
    Nt = min(max(Nt, Nmin), N0);
end

end
