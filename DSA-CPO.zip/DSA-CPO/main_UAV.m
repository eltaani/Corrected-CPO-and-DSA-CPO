%% MAIN_UAV  DSA-CPO and CPO on one 3-D UAV base-station placement scenario
%  5 UAV-BSs, 30 uniformly distributed users, 100 m x 100 m area (paper setup).
%  Both algorithms start from the same initial population (same seed).

clear; clc; close all;
root = fileparts(mfilename('fullpath'));            % folder of this script
addpath(fullfile(root, 'algorithms'), fullfile(root, 'problems'));

P      = UAV_Problem_Setup(5, 30, 1);       % N_d = 5, N_u = 30, user seed 1
fobj   = @(x) UAV_Fitness(x, P);
pop    = 30;
MaxFEs = 30000;

rng(1001, 'twister');                       % run r = 1 of the paper
[F1, X1, c1, info] = DSA_CPO(pop, MaxFEs, P.lb, P.ub, P.dim, fobj);
rng(1001, 'twister');
[F2, X2, c2] = CPO(pop, MaxFEs, P.lb, P.ub, P.dim, fobj);

[~, o1] = UAV_Fitness(X1, P);
[~, o2] = UAV_Fitness(X2, P);
fprintf('DSA-CPO : F = %.4f | coverage = %5.1f %% | mean altitude = %5.2f m\n', ...
        F1, o1.coverage_pct, mean(o1.altitude));
fprintf('CPO     : F = %.4f | coverage = %5.1f %% | mean altitude = %5.2f m\n', ...
        F2, o2.coverage_pct, mean(o2.altitude));

figure('Color', 'w', 'Position', [80 80 1250 400]);
subplot(1, 3, 1); plot_deployment(X1, P, 'DSA-CPO');
subplot(1, 3, 2);
plot(c1, 'LineWidth', 1.4); hold on; plot(c2, 'LineWidth', 1.4);
legend('DSA-CPO', 'CPO'); xlabel('Function evaluations'); ylabel('Best fitness'); grid on;
subplot(1, 3, 3);
plot(info.fe, info.PE, 'LineWidth', 1.4); hold on;
plot(info.fe, info.div, 'LineWidth', 1.2); plot(info.fe, info.stag, ':', 'LineWidth', 1.2);
legend('P_E', 'Div / Div(0)', 'S'); xlabel('Function evaluations'); ylim([0 1]); grid on;
title('DSA-CPO controller');
